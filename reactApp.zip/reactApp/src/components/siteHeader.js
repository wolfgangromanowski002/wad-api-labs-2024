import React from "react";

const Header = (props) => {
  return <p>
      Welcome to the movies!!! 
    </p>
     ;
};

export default Header;