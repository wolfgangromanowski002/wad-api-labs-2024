const PublicPage = () => {
    return <h2>Public page</h2>
 }

 export default PublicPage;